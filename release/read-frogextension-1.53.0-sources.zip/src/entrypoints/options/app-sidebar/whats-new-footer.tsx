import { Icon } from "@iconify/react"
import { useQuery, useQueryClient } from "@tanstack/react-query"
import { useAtomValue } from "jotai"
import { useCallback, useEffect, useEffectEvent, useState } from "react"
import { BlogPostTypeBadge } from "@/components/badges/blog-post-type-badge"
import {
  Popover,
  PopoverContent,
  PopoverDescription,
  PopoverHeader,
  PopoverTitle,
  PopoverTrigger,
} from "@/components/ui/base-ui/popover"
import { SidebarMenu, SidebarMenuButton, SidebarMenuItem } from "@/components/ui/base-ui/sidebar"
import { useResolvedAccountPlan } from "@/components/user-account-menu/shared"
import { env } from "@/env"
import { configFieldsAtomMap } from "@/utils/atoms/config"
import {
  buildBilibiliEmbedUrl,
  getBlogLocaleFromUILanguage,
  getLastViewedBlogDate,
  getLatestBlogDate,
  hasNewBlogPost,
  saveLastViewedBlogDate,
} from "@/utils/blog"
import { i18n } from "@/utils/i18n"
import { version } from "../../../../package.json"

export function WhatsNewFooter() {
  const queryClient = useQueryClient()
  const [open, setOpen] = useState(false)
  const uiLanguage = useAtomValue(configFieldsAtomMap.uiLanguage)
  const blogLocale = getBlogLocaleFromUILanguage(uiLanguage)
  const plan = useResolvedAccountPlan()

  const { data: lastViewedDate, isFetched: isLastViewedDateFetched } = useQuery({
    queryKey: ["last-viewed-blog-date"],
    queryFn: getLastViewedBlogDate,
  })

  const { data: latestBlogPost, isFetched: isLatestBlogPostFetched } = useQuery({
    queryKey: ["latest-blog-post", blogLocale],
    queryFn: () => getLatestBlogDate(`${env.WXT_WEBSITE_URL}/api/blog/latest`, blogLocale, version),
  })

  const markLatestBlogPostViewed = useEffectEvent(async () => {
    if (!latestBlogPost) {
      return
    }

    if (!isLastViewedDateFetched) {
      return
    }

    if (lastViewedDate && lastViewedDate.getTime() >= latestBlogPost.date.getTime()) {
      return
    }

    await saveLastViewedBlogDate(latestBlogPost.date)
    await queryClient.invalidateQueries({ queryKey: ["last-viewed-blog-date"] })
  })

  const handleOpenChange = useCallback((nextOpen: boolean) => {
    setOpen(nextOpen)
  }, [])

  const openPopover = useEffectEvent(() => {
    // eslint-disable-next-line react/set-state-in-effect
    setOpen(true)
  })

  const latestBlogPostDate = latestBlogPost?.date ?? null
  const latestBlogPostKey = latestBlogPost
    ? `${latestBlogPost.url}:${latestBlogPost.date.toISOString()}`
    : null
  const lastViewedDateTimestamp = lastViewedDate?.getTime() ?? null
  // Pro and Ultra already pay, so a sale must not pop open on them; the post
  // stays one click away behind What's New. Hold off until the plan is known,
  // or a paid account would see the sale flash open while billing loads.
  const holdsPromotionBack =
    latestBlogPost?.type === "promotion" &&
    (plan === undefined || plan === "pro" || plan === "ultra")
  const shouldAutoOpenPopover =
    isLastViewedDateFetched &&
    isLatestBlogPostFetched &&
    !holdsPromotionBack &&
    hasNewBlogPost(lastViewedDate ?? null, latestBlogPostDate)

  useEffect(() => {
    if (!shouldAutoOpenPopover) {
      return
    }

    // oxlint-disable-next-line react/set-state-in-effect -- auto-opens the popover once the gate flips
    openPopover()
  }, [shouldAutoOpenPopover])

  // Persist the visible post so it doesn't reopen on the next visit.
  useEffect(() => {
    if (!open) {
      return
    }

    void markLatestBlogPostViewed()
    // oxlint-disable-next-line react/exhaustive-effect-dependencies -- the dependencies are re-run triggers, not values the effect body reads
  }, [isLastViewedDateFetched, lastViewedDateTimestamp, latestBlogPostKey, open])

  if (!latestBlogPost) {
    return null
  }

  const blogUrl = new URL(
    latestBlogPost.urlOverride ?? latestBlogPost.url,
    env.WXT_WEBSITE_URL,
  ).toString()
  const embedUrl = latestBlogPost.videoUrl ? buildBilibiliEmbedUrl(latestBlogPost.videoUrl) : null
  const imageUrl = embedUrl ? null : latestBlogPost.imageUrl

  return (
    <Popover key={latestBlogPostKey} open={open} onOpenChange={handleOpenChange}>
      <SidebarMenu>
        <SidebarMenuItem>
          <PopoverTrigger
            render={
              <SidebarMenuButton
                aria-label={i18n.t("options.whatsNew.title")}
                tooltip={i18n.t("options.whatsNew.title")}
              />
            }
          >
            <Icon icon="tabler:rss" />
            <span>{i18n.t("options.whatsNew.title")}</span>
          </PopoverTrigger>
        </SidebarMenuItem>
      </SidebarMenu>

      <PopoverContent
        align="end"
        initialFocus={(openType) => openType === "keyboard"}
        side="top"
        sideOffset={8}
        className="w-[min(24rem,calc(100vw-2rem))] gap-4 p-3"
      >
        {embedUrl && (
          <div className="overflow-hidden rounded-md border bg-black">
            <iframe
              title={latestBlogPost.title}
              src={embedUrl}
              className="aspect-video w-full"
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
              loading="eager"
              referrerPolicy="strict-origin-when-cross-origin"
              sandbox="allow-popups allow-presentation allow-scripts"
            />
          </div>
        )}
        {imageUrl && (
          <a
            href={blogUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="block overflow-hidden rounded-md border bg-muted"
          >
            <img
              src={imageUrl}
              alt={latestBlogPost.title}
              className="aspect-[1200/630] w-full object-cover"
              loading="eager"
              referrerPolicy="strict-origin-when-cross-origin"
            />
          </a>
        )}

        <PopoverHeader className="gap-2">
          <PopoverTitle>
            {latestBlogPost.type && (
              <BlogPostTypeBadge type={latestBlogPost.type} className="mr-1.5" />
            )}
            <a
              href={blogUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group hover:underline"
            >
              <span className="min-w-0">
                {latestBlogPost.title}
                <Icon
                  aria-hidden="true"
                  icon="tabler:external-link"
                  className="ml-1 inline size-[1em] align-[-0.125em] text-muted-foreground transition-colors group-hover:text-foreground"
                />
              </span>
            </a>
          </PopoverTitle>
          {latestBlogPost.description && (
            <PopoverDescription>{latestBlogPost.description}</PopoverDescription>
          )}
        </PopoverHeader>
      </PopoverContent>
    </Popover>
  )
}
