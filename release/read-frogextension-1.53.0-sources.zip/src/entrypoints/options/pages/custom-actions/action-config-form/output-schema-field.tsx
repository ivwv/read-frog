import type {
  SelectionToolbarCustomAction,
  SelectionToolbarCustomActionOutputField,
} from "@/types/config/selection-toolbar"
import { Icon } from "@iconify/react"
import { LAYOUT_RESERVED_FIELD_NAMES } from "@read-frog/layout-engine/contract"
import { renameLayoutFieldRefs } from "@read-frog/layout-engine/editor"
import { useForm } from "@tanstack/react-form"
import { useEffect, useState } from "react"
import { fieldContext as FieldContext } from "@/components/form/form-context"
import { InputField } from "@/components/form/input-field"
import { QuickInsertableTextareaField } from "@/components/form/quick-insertable-textarea-field"
import { SelectField } from "@/components/form/select-field"
import { useAutosaveContext } from "@/components/form/use-autosave"
import { SortableList } from "@/components/sortable-list"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/base-ui/alert-dialog"
import { Badge } from "@/components/ui/base-ui/badge"
import { Button } from "@/components/ui/base-ui/button"
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/base-ui/dialog"
import { Field, FieldGroup, FieldLabel } from "@/components/ui/base-ui/field"
import {
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/base-ui/select"
import { toastManager } from "@/components/ui/base-ui/toast"
import { selectionToolbarCustomActionOutputTypeSchema } from "@/types/config/selection-toolbar"
import {
  createOutputSchemaField,
  getModelOutputFields,
  getNextOutputFieldName,
  getOutputSchemaFieldNameError,
  getSelectionToolbarCustomActionTokenCellText,
  isSelectionOutputField,
  normalizeOutputSchemaFieldName,
  SELECTION_TOOLBAR_CUSTOM_ACTION_TOKENS,
} from "@/utils/constants/custom-action"
import { i18n } from "@/utils/i18n"
import { CUSTOM_ACTION_LAYOUT_HOST } from "@/utils/layout-host/host"
import { sanitizeCustomActionNotebaseConnection } from "@/utils/notebase/connection"
import { withForm } from "./form"

type CustomActionFormKey =
  | "fieldName"
  | "fieldNamePlaceholder"
  | "fieldType"
  | "fieldDescription"
  | "fieldDescriptionPlaceholder"
  | "editFieldDialog.save"
  | "deleteFieldDialog.title"
  | "deleteFieldDialog.description"
  | "deleteFieldDialog.cancel"
  | "deleteFieldDialog.confirm"
  | "outputSchema"
  | "autoFieldPrefix"
  | "addField"
  | "addFieldDialog.title"
  | "editFieldDialog.title"
  | "selectionField"
  | "selectionFieldDescription"

function t(key: CustomActionFormKey) {
  return i18n.t(`options.selectionToolbar.customActions.form.${key}`)
}

function FieldDialog({
  field: outputField,
  existingFields,
  title,
  open,
  onOpenChange,
  onSave,
}: {
  field: SelectionToolbarCustomActionOutputField
  existingFields: SelectionToolbarCustomActionOutputField[]
  title: string
  open: boolean
  onOpenChange: (open: boolean) => void
  onSave: (updated: SelectionToolbarCustomActionOutputField) => void
}) {
  const form = useForm({
    defaultValues: outputField,
    onSubmit: ({ value }) => {
      onSave({
        ...value,
        name: normalizeOutputSchemaFieldName(value.name),
      })
      onOpenChange(false)
    },
  })

  const validateNameField = (value: string) => {
    const errorType = getOutputSchemaFieldNameError(value, existingFields, outputField.id)
    if (errorType === "blank") {
      return i18n.t("options.selectionToolbar.customActions.errors.fieldKeyRequired")
    }
    if (errorType === "duplicate") {
      return i18n.t("options.selectionToolbar.customActions.errors.duplicateFieldKey")
    }
    // Layouts cannot reach a field named after `ctx` or the loop drop. UI-only on
    // purpose: the config schema must keep accepting fields saved before layouts.
    if (isReservedLayoutName(normalizeOutputSchemaFieldName(value))) {
      return i18n.t("options.selectionToolbar.customActions.form.layout.reservedName")
    }
    return undefined
  }

  const customActionInsertCells = SELECTION_TOOLBAR_CUSTOM_ACTION_TOKENS.map((token) => ({
    text: getSelectionToolbarCustomActionTokenCellText(token),
    description: i18n.t(`options.selectionToolbar.customActions.form.tokens.${token}`),
  }))

  useEffect(() => {
    if (open) {
      form.reset(outputField)
    }
  }, [form, open, outputField])

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <form
          className="grid w-full gap-4"
          onSubmit={(e) => {
            e.preventDefault()
            e.stopPropagation()
            void form.handleSubmit()
          }}
        >
          <DialogHeader>
            <DialogTitle>{title}</DialogTitle>
          </DialogHeader>
          <FieldGroup>
            <form.Field
              name="name"
              validators={{
                onChange: ({ value }) => validateNameField(value),
                onSubmit: ({ value }) => validateNameField(value),
              }}
            >
              {(nameField) => (
                <FieldContext value={nameField}>
                  <InputField label={t("fieldName")} placeholder={t("fieldNamePlaceholder")} />
                </FieldContext>
              )}
            </form.Field>
            {/* A selection field is always text, and the model never reads its
                description: only its name is the user's to set. */}
            {!isSelectionOutputField(outputField) && (
              <form.Field name="type">
                {(typeField) => (
                  <FieldContext value={typeField}>
                    <SelectField
                      label={t("fieldType")}
                      items={selectionToolbarCustomActionOutputTypeSchema.options.map((type) => ({
                        value: type,
                        label: i18n.t(`dataTypes.${type}`),
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectGroup>
                          {selectionToolbarCustomActionOutputTypeSchema.options.map((type) => (
                            <SelectItem key={type} value={type}>
                              {i18n.t(`dataTypes.${type}`)}
                            </SelectItem>
                          ))}
                        </SelectGroup>
                      </SelectContent>
                    </SelectField>
                  </FieldContext>
                )}
              </form.Field>
            )}
            {!isSelectionOutputField(outputField) && (
              <form.Field name="description">
                {(descriptionField) => (
                  <FieldContext value={descriptionField}>
                    <QuickInsertableTextareaField
                      label={t("fieldDescription")}
                      placeholder={t("fieldDescriptionPlaceholder")}
                      className="min-h-20"
                      insertCells={customActionInsertCells}
                    />
                  </FieldContext>
                )}
              </form.Field>
            )}
          </FieldGroup>
          <DialogFooter>
            <form.Subscribe selector={(state) => [state.canSubmit, state.isSubmitting]}>
              {([canSubmit, isSubmitting]) => (
                <Button type="submit" disabled={!canSubmit || isSubmitting}>
                  {t("editFieldDialog.save")}
                </Button>
              )}
            </form.Subscribe>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

const RESERVED_LAYOUT_NAMES = new Set<string>(LAYOUT_RESERVED_FIELD_NAMES)

function isReservedLayoutName(name: string) {
  return RESERVED_LAYOUT_NAMES.has(name)
}

function DeleteFieldDialog({
  open,
  onOpenChange,
  onConfirm,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  onConfirm: () => void
}) {
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{t("deleteFieldDialog.title")}</AlertDialogTitle>
          <AlertDialogDescription>{t("deleteFieldDialog.description")}</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>{t("deleteFieldDialog.cancel")}</AlertDialogCancel>
          <AlertDialogAction variant="destructive" onClick={onConfirm}>
            {t("deleteFieldDialog.confirm")}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

function OutputSchemaRow({
  actions,
  leading,
  outputField,
}: {
  actions?: React.ReactNode
  leading?: React.ReactNode
  outputField: SelectionToolbarCustomActionOutputField
}) {
  return (
    <div className="flex items-center gap-2 rounded-lg border bg-card p-2">
      {leading}
      <span className="shrink-0 text-sm font-medium">{outputField.name}</span>
      {isSelectionOutputField(outputField) ? (
        <>
          <Badge variant="secondary" className="shrink-0">
            {t("selectionField")}
          </Badge>
          <span className="min-w-0 flex-1 truncate text-sm text-muted-foreground">
            {t("selectionFieldDescription")}
          </span>
        </>
      ) : (
        <>
          <Badge variant="secondary" className="shrink-0">
            {i18n.t(`dataTypes.${outputField.type}`)}
          </Badge>
          <span className="min-w-0 flex-1 truncate text-sm text-muted-foreground">
            {outputField.description || "—"}
          </span>
        </>
      )}
      {actions}
    </div>
  )
}

export function ReadOnlyOutputSchemaField({
  outputSchema,
}: {
  outputSchema: SelectionToolbarCustomActionOutputField[]
}) {
  return (
    <Field>
      <FieldLabel>{t("outputSchema")}</FieldLabel>
      <div className="flex flex-col gap-2">
        {outputSchema.map((outputField) => (
          <OutputSchemaRow key={outputField.id} outputField={outputField} />
        ))}
      </div>
    </Field>
  )
}

export const OutputSchemaField = withForm({
  ...{ defaultValues: {} as SelectionToolbarCustomAction },
  render: function Render({ form }) {
    const autosave = useAutosaveContext()
    const [editingField, setEditingField] =
      useState<SelectionToolbarCustomActionOutputField | null>(null)
    const [addingField, setAddingField] = useState<SelectionToolbarCustomActionOutputField | null>(
      null,
    )
    const [deletingFieldId, setDeletingFieldId] = useState<string | null>(null)

    return (
      <form.AppField
        name="outputSchema"
        validators={{
          onChange: ({ value }) => {
            const outputSchema = Array.isArray(value) ? value : []
            // The model has to write something: a selection field alone asks it nothing.
            if (getModelOutputFields(outputSchema).length === 0) {
              return i18n.t("options.selectionToolbar.customActions.errors.outputSchemaRequired")
            }

            for (const outputField of outputSchema) {
              const errorType = getOutputSchemaFieldNameError(
                outputField.name,
                outputSchema,
                outputField.id,
              )
              if (errorType === "blank") {
                return i18n.t("options.selectionToolbar.customActions.errors.fieldKeyRequired")
              }
              if (errorType === "duplicate") {
                return i18n.t("options.selectionToolbar.customActions.errors.duplicateFieldKey")
              }
            }

            return undefined
          },
        }}
      >
        {(field) => {
          const outputSchema = Array.isArray(field.state.value) ? field.state.value : []

          return (
            <Field>
              <div className="flex items-center justify-between">
                <FieldLabel>{t("outputSchema")}</FieldLabel>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const nextName = getNextOutputFieldName(outputSchema, t("autoFieldPrefix"))
                    setAddingField(createOutputSchemaField(nextName))
                  }}
                >
                  <Icon icon="tabler:plus" className="size-4" />
                  {t("addField")}
                </Button>
              </div>

              <SortableList
                list={outputSchema}
                setList={(newList) => {
                  autosave.edit(() => field.handleChange(newList), { immediate: true })
                }}
                className="flex flex-col gap-2"
                renderItem={(outputField) => (
                  <OutputSchemaRow
                    outputField={outputField}
                    leading={
                      <Icon
                        icon="tabler:grip-vertical"
                        className="size-4 shrink-0 text-muted-foreground"
                      />
                    }
                    actions={
                      <div className="flex shrink-0 gap-1">
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          className="size-7"
                          onClick={() => setEditingField(outputField)}
                          onPointerDown={(e) => e.stopPropagation()}
                        >
                          <Icon icon="tabler:pencil" className="size-3.5" />
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          className="size-7"
                          onClick={() => setDeletingFieldId(outputField.id)}
                          onPointerDown={(e) => e.stopPropagation()}
                          disabled={
                            !isSelectionOutputField(outputField) &&
                            getModelOutputFields(outputSchema).length === 1
                          }
                        >
                          <Icon icon="tabler:trash" className="size-3.5" />
                        </Button>
                      </div>
                    }
                  />
                )}
              />

              {addingField && (
                <FieldDialog
                  field={addingField}
                  existingFields={outputSchema}
                  title={t("addFieldDialog.title")}
                  open={!!addingField}
                  onOpenChange={(open) => {
                    if (!open) setAddingField(null)
                  }}
                  onSave={(created) => {
                    autosave.edit(() => field.handleChange([...outputSchema, created]), {
                      immediate: true,
                    })
                    setAddingField(null)
                  }}
                />
              )}

              {editingField && (
                <FieldDialog
                  field={editingField}
                  existingFields={outputSchema}
                  title={t("editFieldDialog.title")}
                  open={!!editingField}
                  onOpenChange={(open) => {
                    if (!open) setEditingField(null)
                  }}
                  onSave={(updated) => {
                    const previous = outputSchema.find((item) => item.id === updated.id)
                    const nextOutputSchema = outputSchema.map((item) =>
                      item.id === updated.id ? updated : item,
                    )
                    let renameSkipped = false
                    autosave.edit(
                      () => {
                        // Move the layout's references in the same write as the rename, so no
                        // saved state has a layout pointing at a field that no longer exists.
                        const layout = form.state.values.layout
                        if (previous && previous.name !== updated.name && layout?.trim()) {
                          const renamed = renameLayoutFieldRefs(
                            layout,
                            [{ from: previous.name, to: updated.name }],
                            CUSTOM_ACTION_LAYOUT_HOST,
                          )
                          if (renamed.changed) form.setFieldValue("layout", renamed.source)
                          renameSkipped = renamed.skipped !== undefined
                        }
                        field.handleChange(nextOutputSchema)
                      },
                      { immediate: true },
                    )
                    if (renameSkipped && previous) {
                      toastManager.add({
                        type: "warning",
                        title: i18n.t(
                          "options.selectionToolbar.customActions.form.layout.renameSkipped",
                          [previous.name],
                        ),
                      })
                    }
                    setEditingField(null)
                  }}
                />
              )}

              <DeleteFieldDialog
                open={!!deletingFieldId}
                onOpenChange={(open) => {
                  if (!open) setDeletingFieldId(null)
                }}
                onConfirm={() => {
                  if (deletingFieldId) {
                    autosave.edit(
                      () => {
                        const nextOutputSchema = field.state.value.filter(
                          (item) => item.id !== deletingFieldId,
                        )
                        const connection = form.state.values.notebaseConnection
                        if (connection) {
                          // Drop references before field validation runs; the persistence
                          // sanitizer cannot repair a draft rejected by handleSubmit.
                          form.setFieldValue(
                            "notebaseConnection",
                            sanitizeCustomActionNotebaseConnection(connection, nextOutputSchema),
                          )
                        }
                        field.handleChange(nextOutputSchema)
                      },
                      { immediate: true },
                    )
                    setDeletingFieldId(null)
                  }
                }}
              />

              {field.state.meta.errors.length > 0 && (
                <span className="text-sm font-normal text-destructive">
                  {field.state.meta.errors.join(", ")}
                </span>
              )}
            </Field>
          )
        }}
      </form.AppField>
    )
  },
})
