import type { APIProviderTypes } from "@/types/config/provider"
import { useSetAtom, useStore } from "jotai"
import { SponsorBadge } from "@/components/badges/sponsor-badge"
import { requestEditorNavigationAtom } from "@/components/form/autosave-navigation"
import ProviderIcon from "@/components/provider-icon"
import { useTheme } from "@/components/providers/theme-provider"
import { DialogContent, DialogHeader, DialogTitle } from "@/components/ui/base-ui/dialog"
import { configFieldsAtomMap } from "@/utils/atoms/config"
import {
  API_PROVIDER_ITEMS,
  PROVIDER_GROUPS,
  getProviderItemName,
} from "@/utils/constants/providers"
import { i18n } from "@/utils/i18n"
import { selectedProviderIdAtom } from "./atoms"
import { addProvider } from "./utils"

export default function AddProviderDialog({ onClose }: { onClose: () => void }) {
  const store = useStore()
  const requestNavigation = useSetAtom(requestEditorNavigationAtom)
  const setProvidersConfig = useSetAtom(configFieldsAtomMap.providersConfig)
  const setSelectedProviderId = useSetAtom(selectedProviderIdAtom)

  const handleAddProvider = async (providerType: APIProviderTypes) => {
    await requestNavigation(async () => {
      await addProvider(
        providerType,
        store.get(configFieldsAtomMap.providersConfig),
        setProvidersConfig,
        setSelectedProviderId,
      )
      onClose()
    })
  }

  return (
    <DialogContent className="max-h-[90vh] overflow-y-auto md:max-w-2xl lg:max-w-4xl xl:max-w-5xl">
      <DialogHeader>
        <DialogTitle>{i18n.t("options.apiProviders.dialog.title")}</DialogTitle>
      </DialogHeader>
      {Object.entries(PROVIDER_GROUPS).map(([groupKey, group]) => (
        <ProviderButtonGroup
          key={groupKey}
          groupTitle={i18n.t(
            `options.apiProviders.dialog.groups.${groupKey as keyof typeof PROVIDER_GROUPS}.title`,
          )}
          groupDescription={i18n.t(
            `options.apiProviders.dialog.groups.${groupKey as keyof typeof PROVIDER_GROUPS}.description`,
          )}
          providerTypes={group.types}
          handleAddProvider={handleAddProvider}
        />
      ))}
    </DialogContent>
  )
}

function ProviderButtonGroup({
  groupTitle,
  groupDescription,
  providerTypes,
  handleAddProvider,
}: {
  groupTitle: string
  groupDescription: string
  providerTypes: readonly APIProviderTypes[]
  handleAddProvider: (providerType: APIProviderTypes) => void
}) {
  return (
    <div className="my-2.5">
      <h3 className="font-base text-input-foreground text-center text-base sm:text-left">
        {groupTitle}
      </h3>
      <p className="mt-1 mb-2 text-center text-sm text-muted-foreground sm:text-left">
        {groupDescription}
      </p>
      <div className="grid grid-cols-4 gap-1.5 py-2 sm:grid-cols-5 md:grid-cols-7 lg:grid-cols-9 xl:grid-cols-11">
        {providerTypes.map((providerType) => (
          <ProviderButton
            key={providerType}
            providerType={providerType}
            handleAddProvider={handleAddProvider}
          />
        ))}
      </div>
    </div>
  )
}

function ProviderButton({
  providerType,
  handleAddProvider,
}: {
  providerType: APIProviderTypes
  handleAddProvider: (providerType: APIProviderTypes) => void
}) {
  const { theme } = useTheme()
  const sponsor = API_PROVIDER_ITEMS[providerType].sponsor
  return (
    <button
      type="button"
      key={providerType}
      className="relative flex h-auto flex-col items-center space-y-1.5 rounded-lg p-2 hover:bg-muted/70"
      onClick={() => handleAddProvider(providerType)}
    >
      {sponsor?.sponsoring && (
        <SponsorBadge
          labelI18nKey={sponsor.badgeI18nKey}
          className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-[65%]"
        />
      )}
      <ProviderIcon logo={API_PROVIDER_ITEMS[providerType].logo(theme)} size="md" />
      <span className="line-clamp-2 flex w-full flex-1 items-center justify-center text-xs font-light">
        {getProviderItemName(providerType)}
      </span>
    </button>
  )
}
