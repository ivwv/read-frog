import type { Config } from "@/types/config/config"
import type { APIProviderConfig, APIProviderTypes } from "@/types/config/provider"
import {
  DEFAULT_PROVIDER_CONFIG,
  getDefaultProviderDescription,
  getProviderItemName,
} from "@/utils/constants/providers"
import { getRandomUUID } from "@/utils/crypto-polyfill"
import { getUniqueName } from "@/utils/name"

export async function addProvider(
  providerType: APIProviderTypes,
  providersConfig: Config["providersConfig"],
  setProvidersConfig: (config: Partial<Config["providersConfig"]>) => Promise<void>,
  setSelectedProviderId?: (id: string) => void,
): Promise<string> {
  const existingNames = new Set(providersConfig.map((p) => p.name))
  const providerName = getUniqueName(getProviderItemName(providerType), existingNames)

  const description = getDefaultProviderDescription(providerType)
  const newProvider: APIProviderConfig = {
    ...structuredClone(DEFAULT_PROVIDER_CONFIG[providerType]),
    ...(description ? { description } : {}),
    id: getRandomUUID(),
    name: providerName,
  }

  const updatedProviders = [...providersConfig, newProvider]
  await setProvidersConfig(updatedProviders)

  if (setSelectedProviderId) {
    setSelectedProviderId(newProvider.id)
  }

  return newProvider.id
}

export async function duplicateProvider(
  providerConfig: APIProviderConfig,
  providersConfig: Config["providersConfig"],
  setProvidersConfig: (config: Partial<Config["providersConfig"]>) => Promise<void>,
  setSelectedProviderId?: (id: string) => void,
): Promise<string> {
  const existingNames = new Set(providersConfig.map((p) => p.name))
  const newProvider: APIProviderConfig = {
    ...structuredClone(providerConfig),
    id: getRandomUUID(),
    name: getUniqueName(providerConfig.name, existingNames),
  }

  const updatedProviders = [...providersConfig, newProvider]
  await setProvidersConfig(updatedProviders)

  if (setSelectedProviderId) {
    setSelectedProviderId(newProvider.id)
  }

  return newProvider.id
}
