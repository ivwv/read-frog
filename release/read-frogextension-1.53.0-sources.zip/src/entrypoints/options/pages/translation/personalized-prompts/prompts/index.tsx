import { PromptManager } from "@/components/prompt-configurator"
import { getBuiltInPageTranslatePrompts } from "@/components/prompt-configurator/built-in-prompts"
import { getTokenCellText, WEB_PAGE_PROMPT_TOKENS } from "@/utils/constants/prompt"
import { i18n } from "@/utils/i18n"
import { ConfigDetailSection } from "../../../../components/config-detail-section"
import { PageLayout } from "../../../../components/page-layout"
import { promptAtoms } from "../atoms"

/**
 * Every prompt Read Frog can translate a page with, drilled into from the Translation page.
 * The community link lives here rather than on the row, which cannot hold a link of its own —
 * the whole row is already one.
 */
export function PersonalizedPromptsPage() {
  const insertCells = WEB_PAGE_PROMPT_TOKENS.map((token) => ({
    text: getTokenCellText(token),
    description: i18n.t(
      `options.translation.personalizedPrompts.editPrompt.promptCellInput.${token}`,
    ),
  }))

  return (
    <PageLayout
      title={i18n.t("options.translation.title")}
      description={i18n.t("options.translation.pageDescription")}
    >
      <ConfigDetailSection
        backTo="/page-translation"
        title={
          <span id="personalized-prompts">
            {i18n.t("options.translation.personalizedPrompts.title")}
          </span>
        }
      >
        <PromptManager
          promptAtoms={promptAtoms}
          insertCells={insertCells}
          builtInPrompts={getBuiltInPageTranslatePrompts()}
          toolbarStart={
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
              <a
                href={i18n.t("options.translation.personalizedPrompts.communityPromptsUrl")}
                target="_blank"
                rel="noreferrer noopener"
                className="text-sm text-link hover:opacity-90"
              >
                {i18n.t("options.translation.personalizedPrompts.communityPrompts")}
              </a>
              <a
                href={i18n.t("options.translation.personalizedPrompts.variableReferenceUrl")}
                target="_blank"
                rel="noreferrer noopener"
                className="text-sm text-link hover:opacity-90"
              >
                {i18n.t("options.translation.personalizedPrompts.variableReference")}
              </a>
            </div>
          }
        />
      </ConfigDetailSection>
    </PageLayout>
  )
}
