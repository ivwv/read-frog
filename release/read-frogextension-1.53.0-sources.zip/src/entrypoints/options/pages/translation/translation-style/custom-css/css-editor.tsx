/**
 * CSS Editor Section Component
 *
 * Main editor interface with live validation and error display.
 * Features:
 * - Real-time CSS validation with 500ms debounce
 * - Save button with validation state
 */

import { useAtom } from "jotai"
import { useMemo, useState } from "react"
import { Button } from "@/components/ui/base-ui/button"
import { Field } from "@/components/ui/base-ui/field"
import { CSSCodeEditor } from "@/components/ui/css-code-editor"
import { env } from "@/env"
import { useDebouncedValue } from "@/hooks/use-debounced-value"
import { MAX_CUSTOM_CSS_LENGTH } from "@/types/config/translate"
import { configFieldsAtomMap } from "@/utils/atoms/config"
import { lintCSS } from "@/utils/css/lint-css"
import { i18n } from "@/utils/i18n"
import { cn } from "@/utils/styles/utils"

export function CSSEditor() {
  const [translateConfig, setTranslateConfig] = useAtom(configFieldsAtomMap.pageTranslation)
  const [cssInput, setCssInput] = useState(translateConfig.translationNodeStyle.customCSS ?? "")

  // Debounce CSS input for validation
  const debouncedCssInput = useDebouncedValue(cssInput, 500)

  // Check CSS syntax using linter
  // Wrap with a dummy selector so css-tree can parse it properly
  const syntaxCheck = useMemo(() => {
    if (!debouncedCssInput.trim()) {
      return { valid: true, errors: [] }
    }
    return lintCSS(debouncedCssInput)
  }, [debouncedCssInput])

  // Check CSS length
  const hasLengthError = debouncedCssInput.length > MAX_CUSTOM_CSS_LENGTH

  const hasSyntaxError = !syntaxCheck.valid
  const isValidating = cssInput !== debouncedCssInput
  const hasChanges = cssInput !== (translateConfig.translationNodeStyle.customCSS ?? "")

  const handleSave = () => {
    // Must pass syntax check and length check
    if (hasSyntaxError || hasLengthError || isValidating || !hasChanges) {
      return
    }

    // Save the original cssInput to preserve user's formatting and indentation
    void setTranslateConfig({
      ...translateConfig,
      translationNodeStyle: {
        ...translateConfig.translationNodeStyle,
        customCSS: cssInput,
      },
    })
  }

  return (
    <Field>
      {/* The section heading already names this editor, so the row carries only the docs link. */}
      <div className="flex items-start justify-end">
        <a
          href={`${env.WXT_WEBSITE_URL}/docs/page-translation/style`}
          className="text-xs text-link hover:opacity-90"
          target="_blank"
          rel="noreferrer"
        >
          {i18n.t("options.translation.translationStyle.customCSS.editor.docsLink")}
        </a>
      </div>
      <CSSCodeEditor
        value={cssInput}
        onChange={setCssInput}
        hasError={hasSyntaxError || hasLengthError}
        placeholder={i18n.t("options.translation.translationStyle.customCSS.editor.placeholder")}
        className="max-h-[400px] min-h-[200px] overflow-y-auto"
      />
      <div className="flex items-center justify-between gap-2">
        <div
          className={cn(
            "text-sm text-success",
            isValidating && "text-muted-foreground",
            (hasSyntaxError || hasLengthError) && "text-destructive",
          )}
        >
          {cssInput.trim().length > 0
            ? getValidationMessage(isValidating, hasSyntaxError, hasLengthError, hasChanges)
            : ""}
        </div>
        <Button
          onClick={handleSave}
          disabled={isValidating || hasSyntaxError || hasLengthError || !hasChanges}
        >
          {hasChanges
            ? i18n.t("options.translation.translationStyle.customCSS.editor.saveButton")
            : i18n.t("options.translation.translationStyle.customCSS.editor.savedButton")}
        </Button>
      </div>
    </Field>
  )
}

function getValidationMessage(
  isValidating: boolean,
  hasSyntaxError: boolean,
  hasLengthError: boolean,
  hasChanges: boolean,
) {
  if (isValidating) {
    return i18n.t("options.translation.translationStyle.customCSS.editor.validation.validating")
  }

  if (hasSyntaxError) {
    return i18n.t("options.translation.translationStyle.customCSS.editor.validation.syntaxError")
  }

  if (hasLengthError) {
    return i18n.t("options.translation.translationStyle.customCSS.editor.validation.tooLong")
  }

  if (!hasChanges) {
    return i18n.t("options.translation.translationStyle.customCSS.editor.validation.saved")
  }

  return i18n.t("options.translation.translationStyle.customCSS.editor.validation.valid")
}
