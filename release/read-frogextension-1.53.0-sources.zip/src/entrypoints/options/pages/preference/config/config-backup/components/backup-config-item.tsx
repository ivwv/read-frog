import type { ConfigBackup, ConfigBackupMetadata } from "@/types/backup"
import { Icon } from "@iconify/react/dist/iconify.js"
import { useMutation } from "@tanstack/react-query"
import { useAtomValue, useSetAtom } from "jotai"
import { useState } from "react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/base-ui/alert-dialog"
import { Button } from "@/components/ui/base-ui/button"
import { ButtonGroup } from "@/components/ui/base-ui/button-group"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/base-ui/dropdown-menu"
import {
  Item,
  ItemActions,
  ItemContent,
  ItemDescription,
  ItemFooter,
  ItemTitle,
} from "@/components/ui/base-ui/item"
import { Spinner } from "@/components/ui/base-ui/spinner"
import { toastManager } from "@/components/ui/base-ui/toast"
import { ViewConfig } from "@/entrypoints/options/components/view-config"
import { useExportConfig } from "@/hooks/use-export-config"
import { configAtom, writeConfigAtom } from "@/utils/atoms/config"
import { addBackup, isSameAsLatestBackup, removeBackup } from "@/utils/backup/storage"
import { migrateConfig } from "@/utils/config/migration"
import { EXTENSION_VERSION } from "@/utils/constants/app"
import { CONFIG_SCHEMA_VERSION } from "@/utils/constants/config"
import { i18n } from "@/utils/i18n"
import { queryClient } from "@/utils/tanstack-query"

interface BackupConfigItemProps {
  backupId: string
  backupMetadata: ConfigBackupMetadata
  backup: ConfigBackup
}

export function BackupConfigItem({ backupId, backupMetadata, backup }: BackupConfigItemProps) {
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  return (
    <Item variant="muted">
      <ItemContent>
        <ItemTitle>{formatDate(backupMetadata.createdAt)}</ItemTitle>
        <ItemDescription className="flex flex-wrap items-center gap-x-4 text-xs">
          <span>
            {i18n.t("options.preference.config.backup.item.extensionVersion")}{" "}
            {backupMetadata.extensionVersion}
          </span>
          <span>
            {i18n.t("options.preference.config.backup.item.schemaVersion")} {backup.schemaVersion}
          </span>
        </ItemDescription>
      </ItemContent>
      <ItemActions>
        <ButtonGroup>
          <RestoreButton backup={backup} />
          <MoreOptions backupId={backupId} backup={backup} />
        </ButtonGroup>
      </ItemActions>
      <ItemFooter>
        <ViewConfig config={backup.config} size="sm" className="w-full" />
      </ItemFooter>
    </Item>
  )
}

function RestoreButton({ backup }: { backup: ConfigBackup }) {
  const [open, setOpen] = useState(false)
  const currentConfig = useAtomValue(configAtom)
  const setConfig = useSetAtom(writeConfigAtom)

  const { mutate: restoreBackup, isPending: isRestoring } = useMutation({
    mutationFn: async (backupToRestore: ConfigBackup) => {
      const migratedBackup = await migrateConfig(
        backupToRestore.config,
        backupToRestore.schemaVersion,
      )

      const isSame = await isSameAsLatestBackup(currentConfig, CONFIG_SCHEMA_VERSION)

      if (!isSame) {
        await addBackup(currentConfig, EXTENSION_VERSION)
      }
      await setConfig(migratedBackup)
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["config-backups"] })
      toastManager.add({
        type: "success",
        title: i18n.t("options.preference.config.backup.restoreSuccess"),
      })
    },
  })

  return (
    <AlertDialog open={open} onOpenChange={setOpen}>
      <AlertDialogTrigger render={<Button variant="outline" size="sm" disabled={isRestoring} />}>
        {isRestoring ? <Spinner /> : <Icon icon="tabler:restore" />}
        {i18n.t("options.preference.config.backup.item.restore")}
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>
            {i18n.t("options.preference.config.backup.restore.title")}
          </AlertDialogTitle>
          <AlertDialogDescription>
            {i18n.t("options.preference.config.backup.restore.description")}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>
            {i18n.t("options.preference.config.backup.restore.cancel")}
          </AlertDialogCancel>
          <AlertDialogAction
            onClick={() => restoreBackup(backup, { onSettled: () => setOpen(false) })}
            disabled={isRestoring}
          >
            {i18n.t("options.preference.config.backup.restore.confirm")}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

function MoreOptions({ backupId, backup }: { backupId: string; backup: ConfigBackup }) {
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [showExportDialog, setShowExportDialog] = useState(false)

  const { mutate: deleteBackup, isPending: isDeleting } = useMutation({
    mutationFn: async (backupIdToDelete: string) => {
      await removeBackup(backupIdToDelete)
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["config-backups"] })
    },
  })

  const { mutate: exportConfig, isPending: isExporting } = useExportConfig({
    config: backup.config,
    schemaVersion: backup.schemaVersion,
    // A stored backup is a config from a particular moment. Today's glossaries
    // were not part of that moment, and attaching them would make the file claim
    // a state that never existed.
    includeGlossary: false,
  })

  return (
    <>
      <DropdownMenu modal={false}>
        <DropdownMenuTrigger
          render={<Button variant="outline" size="icon-sm" disabled={isExporting || isDeleting} />}
        >
          <Icon icon="tabler:dots" />
        </DropdownMenuTrigger>
        <DropdownMenuContent className="w-40" align="end">
          <DropdownMenuItem onClick={() => setShowExportDialog(true)} disabled={isExporting}>
            <Icon icon="tabler:file-export" />
            {i18n.t("options.preference.config.backup.item.export")}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => setShowDeleteDialog(true)}>
            <Icon icon="tabler:trash" />
            {i18n.t("options.preference.config.backup.item.delete")}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {i18n.t("options.preference.config.backup.delete.title")}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {i18n.t("options.preference.config.backup.delete.description")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>
              {i18n.t("options.preference.config.backup.delete.cancel")}
            </AlertDialogCancel>
            <AlertDialogAction
              variant="destructive"
              onClick={() =>
                deleteBackup(backupId, { onSettled: () => setShowDeleteDialog(false) })
              }
              disabled={isDeleting}
            >
              {i18n.t("options.preference.config.backup.delete.confirm")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showExportDialog} onOpenChange={setShowExportDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {i18n.t("options.preference.config.manualSync.exportOptions.title")}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {i18n.t("options.preference.config.manualSync.exportOptions.description")}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex justify-between!">
            <AlertDialogCancel>
              {i18n.t("options.preference.config.manualSync.exportOptions.cancel")}
            </AlertDialogCancel>
            <div className="flex gap-2">
              <AlertDialogAction
                variant="secondary"
                onClick={() => exportConfig(true, { onSettled: () => setShowExportDialog(false) })}
                disabled={isExporting}
              >
                {i18n.t("options.preference.config.manualSync.exportOptions.includeAPIKeys")}
              </AlertDialogAction>
              <AlertDialogAction
                onClick={() => exportConfig(false, { onSettled: () => setShowExportDialog(false) })}
                disabled={isExporting}
              >
                {i18n.t("options.preference.config.manualSync.exportOptions.excludeAPIKeys")}
              </AlertDialogAction>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  )
}
