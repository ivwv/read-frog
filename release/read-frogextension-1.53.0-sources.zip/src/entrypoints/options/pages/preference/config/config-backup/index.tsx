import { Icon } from "@iconify/react/dist/iconify.js"
import { useMutation, useQuery } from "@tanstack/react-query"
import { useAtomValue } from "jotai"
import { Button } from "@/components/ui/base-ui/button"
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/base-ui/empty"
import { toastManager } from "@/components/ui/base-ui/toast"
import { ConfigDetailSection } from "@/entrypoints/options/components/config-detail-section"
import { PageLayout } from "@/entrypoints/options/components/page-layout"
import { configAtom } from "@/utils/atoms/config"
import { addBackup, getAllBackupsWithMetadata } from "@/utils/backup/storage"
import { EXTENSION_VERSION } from "@/utils/constants/app"
import { i18n } from "@/utils/i18n"
import { queryClient } from "@/utils/tanstack-query"
import { BackupConfigItem } from "./components/backup-config-item"

export function ConfigBackupPage() {
  const { data: backupsWithMetadata, isPending } = useQuery({
    queryKey: ["config-backups"],
    queryFn: () => getAllBackupsWithMetadata(),
  })

  return (
    <PageLayout
      title={i18n.t("options.preference.title")}
      description={i18n.t("options.preference.pageDescription")}
    >
      <ConfigDetailSection
        backTo="/preference"
        title={<span id="config-backup">{i18n.t("options.preference.config.backup.title")}</span>}
      >
        <div className="space-y-4">
          {isPending && (
            <div className="py-8 text-center text-muted-foreground">
              <span className="shimmer">{i18n.t("options.preference.config.backup.loading")}</span>
            </div>
          )}

          {backupsWithMetadata && backupsWithMetadata?.length === 0 && <EmptyState />}
          {backupsWithMetadata && backupsWithMetadata?.length > 0 && (
            <>
              <Toolbar />
              {backupsWithMetadata.map((backupWithMetadata) => (
                <BackupConfigItem
                  key={backupWithMetadata.id}
                  backupId={backupWithMetadata.id}
                  backupMetadata={backupWithMetadata.metadata}
                  backup={{
                    schemaVersion: backupWithMetadata.schemaVersion,
                    config: backupWithMetadata.config,
                  }}
                />
              ))}
            </>
          )}
        </div>
      </ConfigDetailSection>
    </PageLayout>
  )
}

function Toolbar() {
  const currentConfig = useAtomValue(configAtom)
  const { mutate: backupConfig, isPending: isBackingUp } = useMutation({
    mutationFn: async () => {
      await addBackup(currentConfig, EXTENSION_VERSION)
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["config-backups"] })
      toastManager.add({
        type: "success",
        title: i18n.t("options.preference.config.backup.backupSuccess"),
      })
    },
  })
  return (
    <div className="flex justify-end">
      <Button size="sm" disabled={isBackingUp} onClick={() => backupConfig()}>
        <Icon icon="tabler:plus" />
        {i18n.t("options.preference.config.backup.backupNow")}
      </Button>
    </div>
  )
}

function EmptyState() {
  const currentConfig = useAtomValue(configAtom)
  const { mutate: backupConfig, isPending: isBackingUp } = useMutation({
    mutationFn: async () => {
      await addBackup(currentConfig, EXTENSION_VERSION)
    },
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["config-backups"] })
      toastManager.add({
        type: "success",
        title: i18n.t("options.preference.config.backup.backupSuccess"),
      })
    },
  })
  return (
    <Empty className="border border-dashed">
      <EmptyHeader>
        <EmptyMedia variant="icon">
          <Icon icon="tabler:file-off" />
        </EmptyMedia>
        <EmptyTitle>{i18n.t("options.preference.config.backup.empty.title")}</EmptyTitle>
        <EmptyDescription>
          {i18n.t("options.preference.config.backup.empty.description")}
        </EmptyDescription>
      </EmptyHeader>
      <EmptyContent>
        <Button variant="outline" size="sm" disabled={isBackingUp} onClick={() => backupConfig()}>
          {i18n.t("options.preference.config.backup.backupNow")}
        </Button>
      </EmptyContent>
    </Empty>
  )
}
