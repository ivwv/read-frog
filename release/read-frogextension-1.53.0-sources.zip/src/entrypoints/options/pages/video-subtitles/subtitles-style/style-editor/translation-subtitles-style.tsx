import { Icon } from "@iconify/react"
import { deepmerge } from "deepmerge-ts"
import { useAtom } from "jotai"
import { Button } from "@/components/ui/base-ui/button"
import { Card } from "@/components/ui/base-ui/card"
import { Label } from "@/components/ui/base-ui/label"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/base-ui/tooltip"
import { configFieldsAtomMap } from "@/utils/atoms/config"
import {
  DEFAULT_FONT_FAMILY,
  DEFAULT_FONT_SCALE,
  DEFAULT_FONT_WEIGHT,
  DEFAULT_SUBTITLE_COLOR,
} from "@/utils/constants/subtitles"
import { i18n } from "@/utils/i18n"
import { SubtitlesTextStyleForm } from "./subtitles-text-style-form"

export function TranslationSubtitlesStyle() {
  const [videoSubtitlesConfig, setVideoSubtitlesConfig] = useAtom(
    configFieldsAtomMap.videoSubtitles,
  )

  const resetSubtitlesStyleConfig = () => {
    void setVideoSubtitlesConfig(
      deepmerge(videoSubtitlesConfig, {
        style: {
          translation: {
            fontFamily: DEFAULT_FONT_FAMILY,
            fontScale: DEFAULT_FONT_SCALE,
            color: DEFAULT_SUBTITLE_COLOR,
            fontWeight: DEFAULT_FONT_WEIGHT,
          },
        },
      }),
    )
  }

  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon icon="tabler:language" className="size-4" />
          <Label className="text-sm font-semibold">
            {i18n.t("options.videoSubtitles.style.translationSubtitle")}
          </Label>
        </div>
        <Tooltip>
          <TooltipTrigger
            render={
              <Button
                variant="ghost"
                size="sm"
                className="-mr-2"
                onClick={resetSubtitlesStyleConfig}
              />
            }
          >
            <Icon icon="tabler:refresh" />
          </TooltipTrigger>
          <TooltipContent>{i18n.t("options.videoSubtitles.style.reset")}</TooltipContent>
        </Tooltip>
      </div>

      <SubtitlesTextStyleForm type="translation" />
    </Card>
  )
}
