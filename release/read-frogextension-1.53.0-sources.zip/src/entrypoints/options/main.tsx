import "@/utils/zod-config"
import type { Config } from "@/types/config/config"
import type { ThemeMode } from "@/types/config/theme"
import { QueryClientProvider } from "@tanstack/react-query"
import { Provider as JotaiProvider } from "jotai"
import { useHydrateAtoms } from "jotai/utils"
import * as React from "react"
import { createHashRouter, RouterProvider } from "react-router"
import { AutosaveNavigation } from "@/components/form/autosave-navigation"
import { ThemeProvider } from "@/components/providers/theme-provider"
import { RecoveryBoundary } from "@/components/recovery/recovery-boundary"
import { SidebarProvider } from "@/components/ui/base-ui/sidebar"
import { AnchoredToastProvider, ToastProvider } from "@/components/ui/base-ui/toast"
import { TooltipProvider } from "@/components/ui/base-ui/tooltip"
import { configAtom } from "@/utils/atoms/config"
import { baseThemeModeAtom } from "@/utils/atoms/theme"
import { getLocalConfig } from "@/utils/config/storage"
import { DEFAULT_CONFIG } from "@/utils/constants/config"
import { initI18n } from "@/utils/i18n"
import { LocaleBoundary } from "@/utils/i18n/locale-boundary"
import { renderPersistentReactRoot } from "@/utils/react-root"
import { queryClient } from "@/utils/tanstack-query"
import { applyTheme, getLocalThemeMode, isDarkMode } from "@/utils/theme"
import App from "./app"
import { AppShell } from "./app-shell"
import { SettingsSearch } from "./command-palette/settings-search"
import { ScrollRestoration } from "./navigation/scroll-restoration"
import "@fontsource-variable/inter/index.css"
import "@/assets/styles/theme.css"
import "./style.css"

function HydrateAtoms({
  initialValues,
  children,
}: {
  initialValues: [[typeof configAtom, Config], [typeof baseThemeModeAtom, ThemeMode]]
  children: React.ReactNode
}) {
  useHydrateAtoms(initialValues)
  return children
}

async function initApp() {
  const root = document.getElementById("root")!
  root.className = "antialiased bg-background"

  const [configValue, themeMode] = await Promise.all([getLocalConfig(), getLocalThemeMode()])
  const config = configValue ?? DEFAULT_CONFIG

  await initI18n(config.uiLanguage)

  applyTheme(document.documentElement, isDarkMode(themeMode) ? "dark" : "light")

  const router = createHashRouter([
    {
      path: "*",
      element: (
        <SidebarProvider>
          <ThemeProvider>
            <TooltipProvider>
              <LocaleBoundary>
                <ToastProvider>
                  <AnchoredToastProvider>
                    <RecoveryBoundary>
                      <ScrollRestoration />
                      <AutosaveNavigation />
                      <AppShell>
                        <App />
                      </AppShell>
                      <SettingsSearch />
                    </RecoveryBoundary>
                  </AnchoredToastProvider>
                </ToastProvider>
              </LocaleBoundary>
            </TooltipProvider>
          </ThemeProvider>
        </SidebarProvider>
      ),
    },
  ])

  renderPersistentReactRoot(
    root,
    <React.StrictMode>
      <JotaiProvider>
        <HydrateAtoms
          initialValues={[
            [configAtom, config],
            [baseThemeModeAtom, themeMode],
          ]}
        >
          <QueryClientProvider client={queryClient}>
            <RouterProvider router={router} />
          </QueryClientProvider>
        </HydrateAtoms>
      </JotaiProvider>
    </React.StrictMode>,
  )
}

void initApp()
