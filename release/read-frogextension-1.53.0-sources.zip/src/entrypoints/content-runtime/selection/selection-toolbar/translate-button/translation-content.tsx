import type { ThinkingSnapshot } from "@/types/background-stream"
import { IconLoader2 } from "@tabler/icons-react"
import { Activity } from "react"
import { Thinking } from "@/components/thinking"
import { CopyButton } from "@/components/ui/selection-popover/copy-button"
import { SelectionSourceContent } from "@/components/ui/selection-popover/selection-source-content"
import { SpeakButton } from "@/components/ui/selection-popover/speak-button"

interface TranslationContentProps {
  selectionContent: string | null | undefined
  translatedText: string | undefined
  isTranslating: boolean
  thinking: ThinkingSnapshot | null
}

export function TranslationContent({
  selectionContent,
  translatedText,
  isTranslating,
  thinking,
}: TranslationContentProps) {
  const showLoadingIndicator = isTranslating && !thinking && !translatedText
  const showStreamingIndicator = isTranslating && !thinking && translatedText
  return (
    <div className="p-4">
      <SelectionSourceContent text={selectionContent} separatorClassName="mb-3" />
      <div className="space-y-2">
        {thinking && <Thinking status={thinking.status} content={thinking.text} />}
        <p className="text-sm [overflow-wrap:anywhere] break-words whitespace-pre-wrap">
          {showLoadingIndicator && (
            <IconLoader2 className="inline size-4 animate-spin" strokeWidth={1.6} />
          )}
          {translatedText}
          {showStreamingIndicator && " ●"}
        </p>
        <Activity mode={translatedText ? "visible" : "hidden"}>
          <div className="flex items-center gap-1">
            <CopyButton text={translatedText} />
            <SpeakButton text={translatedText} />
          </div>
        </Activity>
      </div>
    </div>
  )
}
