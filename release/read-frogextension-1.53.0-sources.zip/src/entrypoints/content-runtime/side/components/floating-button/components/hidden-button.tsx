import type { FloatingButtonSide } from "@/types/config/floating-button"
import { cn } from "@/utils/styles/utils"
import { FloatingButtonTooltip } from "./floating-button-tooltip"

export default function HiddenButton({
  icon,
  label,
  onClick,
  children,
  className,
  side = "right",
  expanded = false,
}: {
  icon: React.ReactNode
  label: string
  onClick: () => void
  children?: React.ReactNode
  className?: string
  side?: FloatingButtonSide
  expanded?: boolean
}) {
  return (
    <FloatingButtonTooltip
      content={label}
      side={side}
      render={
        <button
          type="button"
          aria-label={label}
          className={cn(
            "cursor-pointer rounded-full border border-border bg-white p-1.5 text-neutral-600 shadow-lg transition-transform duration-300 hover:bg-neutral-100 dark:bg-neutral-900 dark:text-neutral-400 dark:hover:bg-neutral-800",
            side === "right" ? "mr-2" : "ml-2",
            expanded ? "translate-x-0" : side === "right" ? "translate-x-12" : "-translate-x-12",
            className,
          )}
          onClick={onClick}
        />
      }
    >
      {icon}
      {children}
    </FloatingButtonTooltip>
  )
}
