import type { VariantProps } from "class-variance-authority"
import type { badgeVariants } from "@/components/ui/base-ui/badge"
import { Icon } from "@iconify/react"
import { Badge } from "@/components/ui/base-ui/badge"
import { i18n } from "@/utils/i18n"
import { cn } from "@/utils/styles/utils"

type SponsorBadgeProps = Pick<VariantProps<typeof badgeVariants>, "size"> & {
  className?: string
  /** Names the sponsor's own offer in place of the generic "Sponsor" wording. */
  labelI18nKey?: string
}

export function SponsorBadge({ size = "sm", className, labelI18nKey }: SponsorBadgeProps) {
  return (
    <Badge
      variant="secondary"
      size={size}
      className={cn(
        "h-4 gap-0.5 border-amber-200 bg-amber-100 px-1.5 text-[9px] font-semibold text-amber-800 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-300",
        className,
      )}
    >
      <Icon icon="tabler:star" className="size-2.5 text-current" />
      {i18n.t((labelI18nKey ?? "options.apiProviders.badges.sponsor") as never)}
    </Badge>
  )
}
