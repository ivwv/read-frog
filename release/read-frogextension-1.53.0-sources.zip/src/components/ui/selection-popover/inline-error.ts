import type { ErrorAction } from "@/utils/error-action"
import { StreamPortError } from "@/utils/content-script/port-streaming"
import { isExtensionContextInvalidatedError } from "@/utils/error/extension-context"
import { extractAISDKErrorMessage } from "@/utils/error/extract-message"
import { i18n } from "@/utils/i18n"

export interface SelectionToolbarInlineError {
  title: string
  description: string
  action?: ErrorAction
}

type SelectionToolbarErrorKind = "translate" | "customAction"
type SelectionToolbarPrecheckErrorCode =
  | "actionUnavailable"
  | "missingSelection"
  | "providerDisabled"
  | "providerUnavailable"

const UNEXPECTED_ERROR_MESSAGE = "Unexpected error occurred"

export function isAbortError(error: unknown) {
  return error instanceof DOMException && error.name === "AbortError"
}

function getErrorTitle(kind: SelectionToolbarErrorKind) {
  return kind === "translate"
    ? i18n.t("translationHub.translationFailed")
    : i18n.t("options.selectionToolbar.errors.customActionFailed")
}

function getErrorFallbackDescription(kind: SelectionToolbarErrorKind) {
  return kind === "translate"
    ? i18n.t("translationHub.translationFailedFallback")
    : i18n.t("options.selectionToolbar.errors.customActionFailedFallback")
}

function getPrecheckErrorDescription(code: SelectionToolbarPrecheckErrorCode) {
  return i18n.t(`options.selectionToolbar.errors.${code}` as never)
}

function toErrorDescription(kind: SelectionToolbarErrorKind, error: unknown) {
  // Raw "Extension context invalidated." tells the user nothing actionable, and
  // the popover's retry button can never recover from it — only a reload can.
  if (isExtensionContextInvalidatedError(error)) {
    return i18n.t("translation.extensionContextInvalidated")
  }

  const message = extractAISDKErrorMessage(error)
  if (!message || message === UNEXPECTED_ERROR_MESSAGE) {
    return getErrorFallbackDescription(kind)
  }

  return message
}

export function createSelectionToolbarPrecheckError(
  kind: SelectionToolbarErrorKind,
  code: SelectionToolbarPrecheckErrorCode,
): SelectionToolbarInlineError {
  return {
    title: getErrorTitle(kind),
    description: getPrecheckErrorDescription(code),
  }
}

export function createSelectionToolbarRuntimeError(
  kind: SelectionToolbarErrorKind,
  error: unknown,
): SelectionToolbarInlineError {
  return {
    title: getErrorTitle(kind),
    description: toErrorDescription(kind, error),
    action: error instanceof StreamPortError ? error.action : undefined,
  }
}
