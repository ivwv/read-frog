import { useSelector } from "@tanstack/react-store"
import { Field, FieldError, FieldLabel } from "@/components/ui/base-ui/field"
import { Input } from "@/components/ui/base-ui/input"
import { useFieldContext } from "./form-context"

export function InputField({
  label,
  labelExtra,
  type,
  ...props
}: {
  label: React.ReactNode
  labelExtra?: React.ReactNode
} & React.InputHTMLAttributes<HTMLInputElement>) {
  const field = useFieldContext<string | number | undefined>()
  const errors = useSelector(field.store, (state) => state.meta.errors)
  const hasError = errors.length > 0

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value

    if (type === "number") {
      if (value === "") {
        field.handleChange(undefined)
      } else {
        const num = Number(value)
        if (!Number.isNaN(num)) {
          field.handleChange(num)
        }
      }
    } else {
      field.handleChange(value)
    }
  }

  return (
    <Field data-invalid={hasError}>
      <div className="flex w-full items-end justify-between">
        <FieldLabel htmlFor={field.name}>{label}</FieldLabel>
        {labelExtra}
      </div>
      <Input
        id={field.name}
        type={type}
        value={field.state.value ?? ""}
        onBlur={field.handleBlur}
        onChange={handleChange}
        aria-invalid={hasError}
        {...props}
      />
      <FieldError>
        {errors.map((error) => (typeof error === "string" ? error : error?.message)).join(", ")}
      </FieldError>
    </Field>
  )
}
