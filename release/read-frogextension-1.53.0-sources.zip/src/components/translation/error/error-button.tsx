import type { APICallError } from "ai"
import { IconAlertCircle } from "@tabler/icons-react"
import { use } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/base-ui/alert"
import { HoverCard, HoverCardContent, HoverCardTrigger } from "@/components/ui/base-ui/hover-card"
import { isExtensionContextInvalidatedError } from "@/utils/error/extension-context"
import { i18n } from "@/utils/i18n"
import { ShadowWrapperContext } from "@/utils/react-shadow-host/create-shadow-host"

export function ErrorButton({ error }: { error: APICallError }) {
  const shadowWrapper = use(ShadowWrapperContext)
  // A stale content script left behind by an extension update has no HTTP
  // exchange to report, so the status-code row would be a fabricated 500.
  const isContextInvalidated = isExtensionContextInvalidatedError(error)

  return (
    <HoverCard>
      <HoverCardTrigger
        delay={0}
        closeDelay={0}
        render={
          <IconAlertCircle className="size-4 cursor-pointer text-destructive hover:text-destructive/90" />
        }
      />
      <HoverCardContent container={shadowWrapper} className="notranslate w-64" render={<Alert />}>
        <IconAlertCircle className="size-4 text-destructive!" />
        <AlertTitle>Translation Error</AlertTitle>
        <AlertDescription className="break-all">
          {!isContextInvalidated && <StatusCode statusCode={error.statusCode ?? 500} />}
          <p className="text-zinc-900 dark:text-zinc-100">
            {isContextInvalidated
              ? i18n.t("translation.extensionContextInvalidated")
              : error.message || "Something went wrong"}
          </p>
        </AlertDescription>
      </HoverCardContent>
    </HoverCard>
  )
}

function StatusCode({ statusCode }: { statusCode: number }) {
  const getStatusCodeColor = (code: number) => {
    const firstDigit = Math.floor(code / 100)
    switch (firstDigit) {
      case 2:
        return "bg-success" // 2xx - Success
      case 3:
        return "bg-blue-500" // 3xx - Redirection
      case 4:
        return "bg-warning" // 4xx - Client Error
      case 5:
        return "bg-destructive" // 5xx - Server Error
      default:
        return "bg-gray-500" // Unknown
    }
  }

  return (
    <div className="mb-2 flex items-center gap-2">
      <div className={`h-2 w-2 rounded-full ${getStatusCodeColor(statusCode)}`} />
      <span className="text-sm font-medium">
        Status Code:
        {statusCode}
      </span>
    </div>
  )
}
