import{r as e}from"./jsx-runtime-DC2sJWHX.js";var t=`@import "@/assets/styles/host-theme.css";\r
\r
[data-read-frog-custom-translation-style="blur"] {\r
  filter: blur(4px);\r
  opacity: 0.75;\r
  transition:\r
    filter 0.1s ease-in-out,\r
    opacity 0.1s ease-in-out;\r
}\r
\r
[data-read-frog-custom-translation-style="blur"]:hover {\r
  filter: blur(0);\r
  opacity: 1;\r
}\r
\r
.read-frog-translated-block-content[data-read-frog-custom-translation-style="blockquote"] {\r
  border-left: 4px solid var(--read-frog-brand);\r
  padding: 4px 0 4px 8px;\r
}\r
\r
[data-read-frog-custom-translation-style="weakened"] {\r
  opacity: 1;\r
  color: var(--read-frog-muted-foreground) !important;\r
}\r
\r
[data-read-frog-custom-translation-style="dashedLine"] {\r
  text-decoration: underline dashed var(--read-frog-brand) !important;\r
  text-underline-offset: 5px;\r
}\r
\r
[data-read-frog-custom-translation-style="border"] {\r
  border: 1px solid var(--read-frog-brand);\r
  padding: 2px 4px;\r
  border-radius: 4px;\r
}\r
\r
[data-read-frog-custom-translation-style="textColor"] {\r
  color: oklch(0.693 0.17 162.48) !important;\r
}\r
\r
[data-read-frog-custom-translation-style="background"] {\r
  background-color: color-mix(in srgb, var(--read-frog-brand) 15%, transparent);\r
  padding: 2px 4px;\r
  border-radius: 4px;\r
}\r
`,n=`:root {\r
  --read-frog-primary: oklch(0.205 0 0);\r
  --read-frog-brand: oklch(76.034% 0.12361 82.191);\r
  --read-frog-foreground: oklch(0.985 0 0);\r
  --read-frog-muted: oklch(0.97 0 0);\r
  --read-frog-muted-foreground: oklch(0.556 0 0);\r
}\r
\r
@media (prefers-color-scheme: dark) {\r
  :root {\r
    --read-frog-primary: oklch(0.922 0 0);\r
    --read-frog-brand: oklch(76.034% 0.12361 82.191);\r
    --read-frog-foreground: oklch(0.205 0 0);\r
    --read-frog-muted: oklch(0.269 0 0);\r
    --read-frog-muted-foreground: oklch(0.708 0 0);\r
  }\r
}\r
`,r=`/* Every \`*\` rule below excludes inline atoms (formula elements cloned into a\r
 * translation, \`.read-frog-inline-atom\`) and their subtrees, so the page's own\r
 * math CSS (KaTeX, MathJax, MathML) keeps rendering them. \`:where()\` adds no\r
 * specificity, so prose cascades exactly as before. */\r
.read-frog-translated-content-wrapper,\r
.read-frog-translated-content-wrapper\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  overflow-wrap: anywhere;\r
  word-break: normal;\r
  user-select: text;\r
  text-decoration-skip-ink: auto;\r
}\r
\r
.read-frog-inline-atom {\r
  overflow-wrap: normal;\r
}\r
\r
.read-frog-translated-block-content {\r
  display: inline-block;\r
  margin: 8px 0 !important;\r
  color: inherit;\r
  font-family: inherit;\r
}\r
\r
.read-frog-translated-block-content[data-read-frog-float-wrap="true"] {\r
  display: block !important;\r
}\r
\r
.read-frog-translated-inline-content {\r
  display: inline;\r
  color: inherit;\r
  font-family: inherit;\r
  text-decoration: inherit;\r
}\r
\r
/* Simplified Chinese - macOS > Windows > Cross-platform > Fallback */\r
.read-frog-translated-content-wrapper[lang="zh"],\r
.read-frog-translated-content-wrapper[lang="zh"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  font-family:\r
    "PingFang SC", "Microsoft YaHei", "Source Han Sans SC", "Noto Sans SC", "Heiti SC",\r
    "WenQuanYi Micro Hei", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial,\r
    sans-serif;\r
}\r
\r
/* Traditional Chinese - macOS > Windows > Cross-platform > Fallback */\r
.read-frog-translated-content-wrapper[lang="zh-TW"],\r
.read-frog-translated-content-wrapper[lang="zh-TW"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  font-family:\r
    "PingFang TC", "Microsoft JhengHei", "Source Han Sans TC", "Noto Sans TC", "Heiti TC",\r
    "STHeiti", "STXihei", "Hiragino Sans TC", "WenQuanYi Zen Hei", -apple-system,\r
    BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;\r
}\r
\r
/* Japanese - macOS/Windows high-quality > Cross-platform > Legacy > Fallback */\r
.read-frog-translated-content-wrapper[lang="ja"],\r
.read-frog-translated-content-wrapper[lang="ja"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  font-family:\r
    "Hiragino Kaku Gothic ProN", "Yu Gothic", "YuGothic", "Meiryo", "Noto Sans JP",\r
    "Source Han Sans JP", "MS PGothic", "MS Gothic", "IPAexGothic", -apple-system,\r
    BlinkMacSystemFont, "Segoe UI", Arial, Helvetica, sans-serif;\r
}\r
\r
/* Arabic script languages - common typography features */\r
.read-frog-translated-content-wrapper[lang="ar"],\r
.read-frog-translated-content-wrapper[lang="ar"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)),\r
.read-frog-translated-content-wrapper[lang="fa"],\r
.read-frog-translated-content-wrapper[lang="fa"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)),\r
.read-frog-translated-content-wrapper[lang="ur"],\r
.read-frog-translated-content-wrapper[lang="ur"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  font-feature-settings:\r
    "rlig" 1,\r
    "calt" 1;\r
}\r
\r
/* Arabic - macOS high-quality > Cross-platform > macOS legacy > Fallback */\r
.read-frog-translated-content-wrapper[lang="ar"],\r
.read-frog-translated-content-wrapper[lang="ar"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  font-family:\r
    "SF Arabic", "Noto Sans Arabic", "Noto Naskh Arabic", "Geeza Pro", "Traditional Arabic",\r
    "Segoe UI", Tahoma, Arial, sans-serif;\r
}\r
\r
/* Persian/Farsi - macOS > Cross-platform > Platform-specific > Fallback */\r
.read-frog-translated-content-wrapper[lang="fa"],\r
.read-frog-translated-content-wrapper[lang="fa"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  font-family:\r
    "SF Arabic", "Noto Sans Arabic", "Geeza Pro", "Iranian Sans", "Segoe UI", Tahoma, Arial,\r
    sans-serif !important;\r
}\r
\r
/* Urdu - Specialized Nastaliq > Cross-platform > Fallback */\r
.read-frog-translated-content-wrapper[lang="ur"],\r
.read-frog-translated-content-wrapper[lang="ur"]\r
  *:not(:where(.read-frog-inline-atom, .read-frog-inline-atom *)) {\r
  font-family:\r
    "Noto Nastaliq Urdu", "Jameel Noori Nastaleeq", "SF Arabic", "Noto Sans Arabic",\r
    "Alvi Nastaleeq", "Segoe UI", Tahoma, Arial, sans-serif;\r
}\r
`;function i(e){return e.nodeType===Node.DOCUMENT_NODE}function a(e){return i(e)?e:e.ownerDocument??document}var o=new WeakMap;function s(t){let n=o.get(t);if(n!==void 0)return n;try{if(typeof CSSStyleSheet>`u`||a(t)!==document||!(`adoptedStyleSheets`in t)||t.adoptedStyleSheets===void 0)return o.set(t,!1),!1;let e=new CSSStyleSheet,n=[...t.adoptedStyleSheets];try{t.adoptedStyleSheets=[...n,e];let r=[...t.adoptedStyleSheets].includes(e);return o.set(t,r),r}finally{t.adoptedStyleSheets=n}}catch(n){return e.warn(`[style-injector] constructable stylesheet assignment failed, falling back to <style>`,n),o.set(t,!1),!1}}function c(e,t,n){let r=i(e)?e.head:e,o=e.querySelector(`#${t}`);o||(o=a(e).createElement(`style`),o.id=t,r.appendChild(o)),o.textContent!==n&&(o.textContent=n)}var l=t.replace(/@import[^;]+;/g,``)+r,u=n+l,d=n.replace(/:root/g,`:host`)+l,f=new WeakSet,p=null,m=null;function h(e){return i(e)?u:d}function g(e){return i(e)?(p||(p=new CSSStyleSheet,p.replaceSync(u)),p):(m||(m=new CSSStyleSheet,m.replaceSync(d)),m)}function _(e){f.has(e)||(f.add(e),s(e)?e.adoptedStyleSheets=[...e.adoptedStyleSheets,g(e)]:c(e,`read-frog-preset-styles`,h(e)))}var v=`read-frog-subtitles-custom-styles`,y=new WeakMap;async function b(e,t){if(s(e)){let n=y.get(e);n||(n=new CSSStyleSheet,y.set(e,n),e.adoptedStyleSheets=[...e.adoptedStyleSheets,n]),await n.replace(t)}else c(e,v,t)}var x=`read-frog-custom-styles`,S=new WeakMap,C=null;async function w(e){(S.has(e)||e.querySelector(`#${x}`))&&await T(e,``)}async function T(e,t){if(_(e),e!==document||C!==t){if(s(e)){let n=S.get(e);n||(n=new CSSStyleSheet,S.set(e,n),e.adoptedStyleSheets=[...e.adoptedStyleSheets,n]),await n.replace(t)}else c(e,x,t);e===document&&(C=t)}}export{b as i,T as n,_ as r,w as t};